# unzip *.zip using bash script in the floder first.


find . -iname "flag" -type f -exec cat{}\; <br/>
while [$?-eq 0]; do cd flag/; done
